# frozen_string_literal: true

class DeviseCreateUsers < ActiveRecord::Migration
  def change
  end
end
